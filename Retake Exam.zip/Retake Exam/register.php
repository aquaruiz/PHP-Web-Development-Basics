<?php

require_once 'common.php';

$userHttpHandler->register($userService, $_POST);