<h1>VIEW ITEM</h1>

<p>
    <a href="profile.php">My profile</a>|
</p>
<p><b>Title: </b></p>
<p><b>Price: </b></p>
<p><b>Category: </b></p>
<p><b>Phone: </b></p>
<p><b>Description: </b></p>
<div>
    <img src="<?='bababa'?>" alt="Item photo" />
</div>