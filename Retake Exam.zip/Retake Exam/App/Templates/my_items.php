<?php /** @var \App\Data\ItemDTO[] $data */ ?>

<h1>MY ITEMS</h1>

<p>
    <a href="add_item.php">Add new Item</a>|
    <a href="profile.php">My profile</a>|
    <a href="logout.php">Logout</a>
</p>
<table border="1">
    <thead>
    <tr>
        <th>Title</th>
        <th>Category</th>
        <th>Price</th>
        <th>Edit</th>
        <th>Delete</th>
    </tr>
    </thead>
    <tbody>
        <?php foreach ($data as $item) : ?>
            <tr>
                <td><?= $item->getTitle() ?></td>
                <td><?= $item->getCategory()->getName(); ?></td>
                <td><?= $item->getPrice(); ?></td>
                <td><a href="edit_item.php.php?id=<?= $book->getId(); ?>">Edit</a></td>
                <td><a href="delete_item.php?id=<?= $book->getId(); ?>">Delete</a></td>
            </tr>
        <?php endforeach;?>
    </tbody>
</table>