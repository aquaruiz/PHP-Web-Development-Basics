<?php
    /** @var \App\Data\UserDTO $data */
?>
<h1>HELLO, <?=strtoupper($data->getFullName());?>!</h1>

<div>
    <a href="add_item.php">Add new Item</a>|
    <a href="logout.php">Logout</a>
</div>
<div>
    <p>
        <a href="my_items.php">My Items</a>
    </p>
    <p>
        <a href="all_items.php">All Items</a>
    </p>
</div>