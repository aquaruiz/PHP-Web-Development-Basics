<h1>EDIT ITEM</h1>
<p><?=$_SESSION['error']??null;?></p>
<p><a href="profile.php">My Profile</a></p>
<div>
    <label>
        Title: <input type="text" value="" name="title" />
    </label>
</div>
<div>
    <label>
        Price: <input type="number" value="" name="price" />
    </label>
</div>
<div>
    <label>Category:
        <select name="category">
            <option>Choose an option...</option>
        </select>
    </label>
</div>
<div>
    <label>Description:
        <textarea name="description">Value....</textarea>
    </label>
</div>
<div>
    <label>
        Image URL: <input type="text" value="" name="image" />
    </label>
</div>
<div>
    <img src="<?='bababa'?>" alt="Item photo" />
</div>
<div>
    <input type="submit" name="edit" value="Save" />
</div>
<a href="all_items.php">List</a>