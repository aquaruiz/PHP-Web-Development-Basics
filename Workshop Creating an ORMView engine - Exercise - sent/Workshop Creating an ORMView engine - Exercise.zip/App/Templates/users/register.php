<h1>User Registration</h1>

<form method="post">
    <div>
        <label for="username">Username:</label>
        <input type="text" name="username" required>
    </div>
    <div>
        <label for="password">Password:</label>
        <input type="text" name="password" required>
    </div>
    <div>
        <label for="confirm_password">Confirm password:</label>
        <input type="text" name="confirm_password" required>
    </div>
    <div>
        <label for="first_name">First name:</label>
        <input type="text" name="firstName">
    </div>
    <div>
        <label for="last_name">Last name:</label>
        <input type="text" name="lastName">
    </div>
    <div>
        <label for="born_on">Birthday:</label>
        <input type="text" name="bornOn">
    </div>
    <div>
        <input type="submit" name="register" value="Register">
    </div>
</form>