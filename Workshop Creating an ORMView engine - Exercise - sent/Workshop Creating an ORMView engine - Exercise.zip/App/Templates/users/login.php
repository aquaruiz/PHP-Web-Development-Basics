<h1>Login User</h1>

<form method="post">
    <div>
        <label for="username">Username:</label>
        <input type="text" name="username" required>
    </div>
    <div>
        <label for="password">Password:</label>
        <input type="text" name="password" required>
    </div>
    <div>
        <input type="submit" name="login" value="Login">
    </div>
</form>