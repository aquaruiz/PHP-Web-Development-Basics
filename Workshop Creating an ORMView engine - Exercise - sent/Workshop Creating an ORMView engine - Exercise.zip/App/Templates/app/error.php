<?php /** @var \App\Data\ErrorDTO $data */?>

<h1>Oops, an error occurred :(</h1>
<p><strong><?=$data->getMessage()?></strong></p>