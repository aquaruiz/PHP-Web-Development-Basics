<?php
require_once "common.php";

$httpHandler->register($userService, $_POST);