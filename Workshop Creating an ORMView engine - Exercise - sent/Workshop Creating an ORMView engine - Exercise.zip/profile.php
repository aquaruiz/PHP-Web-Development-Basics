<?php
require_once "common.php";

$httpHandler->edit($userService, $_POST);